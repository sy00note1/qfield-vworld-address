import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield

Item {
    id: plugin
    property string apiKey: ""
    property string lastAddress: ""
    property bool busy: false
    property string coordsX: "14157906.570"
    property string coordsY: "4531952.655"

    function lookup() {
        if (!apiKey.trim()) { status.text = "먼저 VWorld 인증키를 입력하세요."; return; }
        var x = Number(xField.text), y = Number(yField.text)
        if (!isFinite(x) || !isFinite(y)) { status.text = "좌표를 확인하세요."; return; }
        var url = "https://api.vworld.kr/req/address?service=address&request=getAddress&version=2.0&crs=EPSG:3857&point="
                + encodeURIComponent(x + "," + y) + "&format=json&type=PARCEL&key=" + encodeURIComponent(apiKey.trim())
        busy = true
        status.text = "조회 중..."
        var req = new XMLHttpRequest()
        req.onreadystatechange = function() {
            if (req.readyState !== XMLHttpRequest.DONE) return
            busy = false
            if (req.status !== 200) { status.text = "연결 실패 (HTTP " + req.status + ")"; return; }
            try {
                var data = JSON.parse(req.responseText)
                var resp = data.response || {}
                if (resp.status !== "OK" || !resp.result || !resp.result.length) {
                    status.text = "주소 검색 결과 없음: " + (resp.status || "응답 오류")
                    return
                }
                var entry = resp.result[0]
                var addr = entry.text || (entry.structure && entry.structure.level4LC) || "주소 텍스트 없음"
                lastAddress = addr
                status.text = "지번주소: " + addr
            } catch(e) { status.text = "응답 처리 오류: " + e; }
        }
        req.open("GET", url)
        req.send()
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(actionButton)
    }

    ToolButton {
        id: actionButton
        text: "주소"
        onClicked: { iface.mainWindow().displayToast("주소조회 창 열기"); dialog.open() }
    }

    Dialog {
        id: dialog
        title: "VWorld 지번주소 조회 (시험판)"
        modal: true
        parent: iface.mainWindow().contentItem
        visible: false
        anchors.centerIn: parent
        width: Math.min(parent ? parent.width - 24 : 360, 420)
        standardButtons: Dialog.Close

        contentItem: ColumnLayout {
            spacing: 10
            Label { text: "API 키는 이 창에서만 입력됩니다. 앱 재시작 시 다시 입력해야 합니다."; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            TextField { id: keyField; placeholderText: "VWorld 인증키"; echoMode: TextInput.Password; Layout.fillWidth: true; onTextChanged: plugin.apiKey = text }
            Label { text: "QField 좌표 EPSG:3857" }
            TextField { id: xField; text: plugin.coordsX; placeholderText: "X"; Layout.fillWidth: true; inputMethodHints: Qt.ImhFormattedNumbersOnly }
            TextField { id: yField; text: plugin.coordsY; placeholderText: "Y"; Layout.fillWidth: true; inputMethodHints: Qt.ImhFormattedNumbersOnly }
            Button { text: busy ? "조회 중" : "지번주소 조회"; enabled: !busy; Layout.fillWidth: true; onClicked: plugin.lookup() }
            Label { id: status; text: "어제 확인한 좌표가 기본 입력되어 있습니다."; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        }
    }
}
