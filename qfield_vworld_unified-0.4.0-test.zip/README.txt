Experimental unified toolbar. Disable old 0.2.0 and 0.3.x only after installing and testing this version. Reverse lookup: tap 주소 then tap a map point. Search: tap 주소검색. Requires a VWorld API key.
