import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var geometryHighlighter: iface.findItemByObjectName("geometryHighlighter")
    property bool waitingForTap: false
    property string latestAddress: ""
    property real longitude: 0
    property real latitude: 0
    property bool hasPoint: false
    property string statusText: "지번 또는 도로명주소를 입력하세요."

    property string apiKey: ""  // Enter per app session; not saved on device

    function configure() { searchDialog.open() }
    function searchAddress() {
        var address = addressInput.text.trim()
        if (!address) { statusText = "주소를 입력하세요."; return }
        if (!plugin.apiKey.trim()) { statusText = "먼저 VWorld API 키를 입력하세요."; return }
        statusText = "검색 중..."
        var types = ["PARCEL", "ROAD"]
        var i = 0
        function attempt() {
            if (i >= types.length) { statusText = "검색 실패: 전체 주소를 입력하거나 API 키/인증 제한을 확인하세요."; return }
            var typ = types[i++]
            var url = "https://api.vworld.kr/req/address?service=address&request=getcoord&version=2.0&format=json&crs=epsg:4326&type=" + typ + "&address=" + encodeURIComponent(address) + "&key=" + encodeURIComponent(plugin.apiKey.trim())
            var xhr = new XMLHttpRequest()
            xhr.onreadystatechange = function() {
                if (xhr.readyState !== XMLHttpRequest.DONE) return
                if (xhr.status !== 200) { if (i < types.length) attempt(); else statusText = "네트워크/API 오류 (HTTP " + xhr.status + ")"; return }
                try {
                    var data = JSON.parse(xhr.responseText)
                    var response = data.response || {}
                    var point = response.result && response.result.point
                    if (response.status === "OK" && point) {
                        var x = Number(point.x), y = Number(point.y)
                        if (!isFinite(x) || !isFinite(y)) { attempt(); return }
                        plugin.longitude = x; plugin.latitude = y
                        plugin.hasPoint = true; plugin.latestAddress = address
                        var geographic = QfGeometryUtils.point(x,y)
                        var projected = QfGeometryUtils.reprojectPoint(geographic, CoordinateReferenceSystemUtils.wgs84Crs(), qgisProject.crs)
                        iface.mapCanvas().mapSettings.center = projected
                        // Temporary point highlight; does not edit any QGIS layers.
                        try {
                            if (plugin.geometryHighlighter && plugin.geometryHighlighter.geometryWrapper) {
                                var markerGeometry = QfGeometryUtils.createGeometryFromWkt("POINT(" + x + " " + y + ")")
                                plugin.geometryHighlighter.geometryWrapper.qgsGeometry = markerGeometry
                                plugin.geometryHighlighter.geometryWrapper.crs = CoordinateReferenceSystemUtils.wgs84Crs()
                                plugin.geometryHighlighter.visible = true
                                if (plugin.geometryHighlighter.update) plugin.geometryHighlighter.update()
                            }
                        } catch (markerError) {
                            console.log("Temporary point highlight unavailable: " + markerError)
                        }
                        statusText = "검색 완료: " + address + " (" + y.toFixed(6) + ", " + x.toFixed(6) + ")"
                        searchDialog.close()
                        iface.mainWindow().displayToast("주소 위치로 이동했습니다: " + address)
                    } else { attempt() }
                } catch (e) { statusText = "응답 처리 오류: " + e }
            }
            xhr.open("GET", url)
            xhr.send()
        }
        attempt()
    }

    // One toolbar item owns both labels; avoid visual transforms entirely.
    Column {
        id: combinedToolbar
        objectName: "vworldUnifiedToolbar"
        width: 100
        spacing: 0
        Button {
            id: reverseButton
            width: 100; height: 38
            text: "주소"
            background: Rectangle { color: "transparent" }
            contentItem: Text {
                text: reverseButton.text; color: "white"; font.pixelSize: 14
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }
            onClicked: {
                plugin.waitingForTap = true
                iface.mainWindow().displayToast("주소를 확인할 지도 지점을 한 번 눌러주세요.")
            }
        }
        Button {
            id: searchButton
            width: 100; height: 38
            text: "주소검색"
            background: Rectangle { color: "transparent" }
            contentItem: Text {
                text: searchButton.text; color: "white"; font.pixelSize: 14
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }
            onClicked: searchDialog.open()
        }
    }

    Connections {
        target: iface.mapCanvas()
        function onConfirmedClicked(point) {
            if (!plugin.waitingForTap) return
            plugin.waitingForTap = false
            try {
                var projected = iface.mapCanvas().mapSettings.screenToCoordinate(point)
                var geo = QfGeometryUtils.reprojectPoint(projected, qgisProject.crs, CoordinateReferenceSystemUtils.wgs84Crs())
                plugin.lookupCoordinate(geo.x, geo.y)
            } catch(e) {
                iface.mainWindow().displayToast("좌표를 읽을 수 없습니다: " + e)
            }
        }
    }

    function lookupCoordinate(x, y) {
        if (!plugin.apiKey.trim()) {
            reverseStatus.text = "VWorld API 키를 입력한 뒤 다시 눌러주세요."
            reverseDialog.open(); return
        }
        var url = "https://api.vworld.kr/req/address?service=address&request=getAddress&version=2.0&format=json&crs=epsg:4326&point=" + encodeURIComponent(x + "," + y) + "&type=BOTH&key=" + encodeURIComponent(plugin.apiKey.trim())
        var xhr = new XMLHttpRequest()
        xhr.onreadystatechange = function() {
            if(xhr.readyState !== XMLHttpRequest.DONE) return
            try {
                if (xhr.status !== 200) throw "HTTP " + xhr.status
                var body = JSON.parse(xhr.responseText).response || {}
                if(body.status !== "OK" || !body.result || !body.result.length) throw "주소 검색 결과 없음"
                var result = body.result[0]
                reverseStatus.text = result.text || "주소 확인 완료"
            } catch (e) { reverseStatus.text = "주소조회 실패: " + e }
            reverseDialog.open()
        }
        xhr.open("GET",url); xhr.send()
    }

    Dialog {
        id: reverseDialog
        parent: iface.mainWindow().contentItem
        modal: true
        title: "VWorld 주소 확인"
        width: Math.min(380,parent.width-24)
        x: (parent.width-width)/2; y: Math.max(20,(parent.height-height)/3)
        standardButtons: Dialog.Close
        contentItem: ColumnLayout {
            Label { id: reverseStatus; text: "주소 조회 중..."; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            Label { text: "VWorld API 키" }
            TextField { Layout.fillWidth: true; text: plugin.apiKey; echoMode: TextInput.Password; onTextChanged: plugin.apiKey = text }
        }
    }

    Dialog {
        id: searchDialog
        parent: iface.mainWindow().contentItem
        modal: true
        title: "VWorld 주소 검색"
        width: Math.min(380, parent.width - 24)
        x: (parent.width-width)/2
        y: Math.max(20,(parent.height-height)/3)
        standardButtons: Dialog.Close
        contentItem: ColumnLayout {
            spacing: 10
            Label { text: "지번주소 또는 도로명주소"; wrapMode: Text.WordWrap }
            TextField {
                id: addressInput
                Layout.fillWidth: true
                placeholderText: "예: 남양주시 퇴계원읍 퇴계원리 97-3"
                inputMethodHints: Qt.ImhNoPredictiveText
                onAccepted: plugin.searchAddress()
            }
            Button { text: "주소 검색 및 지도 이동"; Layout.fillWidth: true; onClicked: plugin.searchAddress() }
            Label { text: "VWorld API 인증키 (앱 실행 시 입력)"; wrapMode: Text.WordWrap }
            TextField {
                id: apiInput
                Layout.fillWidth: true
                text: plugin.apiKey
                echoMode: TextInput.Password
                placeholderText: "인증키 입력"
                onTextChanged: plugin.apiKey = text
            }
            Label { text: plugin.statusText; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            Label { text: "※ 검색 위치에 임시 점 강조를 시도합니다. 관로·밸브 레이어에는 저장하지 않습니다."; wrapMode: Text.WordWrap; Layout.fillWidth: true; font.pixelSize: 12 }
        }
    }
    Component.onCompleted: iface.addItemToPluginsToolbar(combinedToolbar)
}
