0.3.3 visual-alignment test: compact search label shifted right and up; all address-search and temporary marker logic unchanged. Keep 0.2.0 installed. Uninstall 0.3.2 before installing this ZIP.
