QField VWorld Search 0.3.0 TEST

This is a separate plugin from the working 0.2.0 reverse-geocoding plugin.
Use the new search icon in the plugin toolbar. Enter your own VWorld API key and full parcel or road address.
The plugin will first query PARCEL and then ROAD, then re-center the map on EPSG:4326 transformed to the project CRS.
No persisted point layer is created. Requires internet and a valid VWorld API key.
Not tested on an Android device.
