import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Qt.labs.settings
import org.qfield.org
import org.qfield.gui

Item {
    id: plugin
    property string latestAddress: ""
    property real longitude: 0
    property real latitude: 0
    property bool hasPoint: false
    property string statusText: "지번 또는 도로명주소를 입력하세요."

    Settings {
        id: prefs
        category: "vworld_address_search_v030"
        property string apiKey: ""
    }

    function configure() { searchDialog.open() }
    function searchAddress() {
        var address = addressInput.text.trim()
        if (!address) { statusText = "주소를 입력하세요."; return }
        if (!prefs.apiKey.trim()) { statusText = "먼저 VWorld API 키를 입력하세요."; return }
        statusText = "검색 중..."
        var types = ["PARCEL", "ROAD"]
        var i = 0
        function attempt() {
            if (i >= types.length) { statusText = "검색 실패: 전체 주소를 입력하거나 API 키/인증 제한을 확인하세요."; return }
            var typ = types[i++]
            var url = "https://api.vworld.kr/req/address?service=address&request=getcoord&version=2.0&format=json&crs=epsg:4326&type=" + typ + "&address=" + encodeURIComponent(address) + "&key=" + encodeURIComponent(prefs.apiKey.trim())
            var xhr = new XMLHttpRequest()
            xhr.onreadystatechange = function() {
                if (xhr.readyState !== XMLHttpRequest.DONE) return
                if (xhr.status !== 200) { if (i < types.length) attempt(); else statusText = "네트워크/API 오류 (HTTP " + xhr.status + ")"; return }
                try {
                    var data = JSON.parse(xhr.responseText)
                    var response = data.response || {}
                    var point = response.result && response.result.point
                    if (response.status === "OK" && point) {
                        var x = Number(point.x), y = Number(point.y)
                        if (!isFinite(x) || !isFinite(y)) { attempt(); return }
                        plugin.longitude = x; plugin.latitude = y
                        plugin.hasPoint = true; plugin.latestAddress = address
                        var geographic = QfGeometryUtils.point(x,y)
                        var projected = QfGeometryUtils.reprojectPoint(geographic, CoordinateReferenceSystemUtils.wgs84Crs(), qgisProject.crs)
                        iface.mapCanvas().mapSettings.center = projected
                        statusText = "검색 완료: " + address + " (" + y.toFixed(6) + ", " + x.toFixed(6) + ")"
                        searchDialog.close()
                        iface.mainWindow().displayToast("주소 위치로 이동했습니다: " + address)
                    } else { attempt() }
                } catch (e) { statusText = "응답 처리 오류: " + e }
            }
            xhr.open("GET", url)
            xhr.send()
        }
        attempt()
    }

    QfToolButton {
        id: searchButton
        iconSource: Theme.getThemeVectorIcon("ic_search_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        onClicked: searchDialog.open()
    }

    Dialog {
        id: searchDialog
        parent: iface.mainWindow().contentItem
        modal: true
        title: "VWorld 주소 검색"
        width: Math.min(380, parent.width - 24)
        x: (parent.width-width)/2
        y: Math.max(20,(parent.height-height)/3)
        standardButtons: Dialog.Close
        contentItem: ColumnLayout {
            spacing: 10
            Label { text: "지번주소 또는 도로명주소"; wrapMode: Text.WordWrap }
            TextField {
                id: addressInput
                Layout.fillWidth: true
                placeholderText: "예: 남양주시 퇴계원읍 퇴계원리 97-3"
                inputMethodHints: Qt.ImhNoPredictiveText
                onAccepted: plugin.searchAddress()
            }
            Button { text: "주소 검색 및 지도 이동"; Layout.fillWidth: true; onClicked: plugin.searchAddress() }
            Label { text: "VWorld API 인증키 (최초 1회 입력)"; wrapMode: Text.WordWrap }
            TextField {
                id: apiInput
                Layout.fillWidth: true
                text: prefs.apiKey
                echoMode: TextInput.Password
                placeholderText: "인증키 입력"
                onTextChanged: prefs.apiKey = text
            }
            Label { text: plugin.statusText; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            Label { text: "※ 검색 결과는 지도 중심 이동만 합니다. 관로·밸브 레이어는 변경하지 않습니다."; wrapMode: Text.WordWrap; Layout.fillWidth: true; font.pixelSize: 12 }
        }
    }
    Component.onCompleted: iface.addItemToPluginsToolbar(searchButton)
}
