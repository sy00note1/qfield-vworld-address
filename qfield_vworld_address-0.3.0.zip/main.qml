import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Qt.labs.settings 1.0
import org.qfield

Item {
    id: plugin
    property string apiKey: ""
    property bool busy: false
    property string coordsX: ""
    property string coordsY: ""
    property bool capturedPoint: false
    property bool keepKey: false
    property string parcelAddress: ""
    property string roadAddress: ""
    property string captureInfo: "지도에서 위치를 길게 눌러 주세요."
    property int lookupSerial: 0
    property int outstanding: 0

    Settings {
        id: preferences
        category: "vworld-qfield-address-v030"
        property bool rememberKey: false
        property string savedKey: ""
    }

    function recordMapPoint(point) {
        try {
            var result = iface.mapCanvas().mapSettings.screenToCoordinate(point)
            if (!result || !isFinite(result.x) || !isFinite(result.y)) return
            coordsX = Number(result.x).toFixed(3)
            coordsY = Number(result.y).toFixed(3)
            xField.text = coordsX
            yField.text = coordsY
            capturedPoint = true
            captureInfo = "선택 좌표: " + coordsX + ", " + coordsY
            parcelAddress = ""
            roadAddress = ""
            status.text = ""
            if (apiKey.trim()) {
                lookup()
            } else {
                captureInfo += " — 주소 버튼에서 인증키를 입력하면 조회됩니다."
            }
        } catch (e) {
            captureInfo = "좌표 가져오기 실패: " + e
        }
    }

    Connections {
        target: iface.mapCanvas()
        function onLongPressed(point, type) { plugin.recordMapPoint(point) }
    }

    function copyAddress(value) {
        if (!value || value === "검색 결과 없음") return
        try {
            platformUtilities.copyTextToClipboard(value)
            iface.mainWindow().displayToast("주소 복사 완료")
        } catch(e) {
            status.text = "복사 실패: " + e
        }
    }

    function queryAddress(type, serial) {
        var x = Number(coordsX), y = Number(coordsY)
        var url = "https://api.vworld.kr/req/address?service=address&request=getAddress&version=2.0&crs=EPSG:3857&point="
            + encodeURIComponent(x + "," + y) + "&format=json&type=" + type + "&key=" + encodeURIComponent(apiKey.trim())
        var req = new XMLHttpRequest()
        req.onreadystatechange = function() {
            if (req.readyState !== XMLHttpRequest.DONE || serial !== lookupSerial) return
            var value = "검색 결과 없음"
            if (req.status === 200) {
                try {
                    var resp = JSON.parse(req.responseText).response || {}
                    if (resp.status === "OK" && resp.result && resp.result.length) {
                        value = resp.result[0].text || "검색 결과 없음"
                    } else if (resp.status && resp.status !== "NOT_FOUND") {
                        value = "조회 오류: " + resp.status
                    }
                } catch(e) { value = "응답 해석 오류" }
            } else { value = "연결 오류: HTTP " + req.status }
            if (type === "PARCEL") parcelAddress = value
            else roadAddress = value
            outstanding -= 1
            if (outstanding <= 0) {
                busy = false
                status.text = "조회 완료"
            }
        }
        req.open("GET", url)
        req.send()
    }

    function lookup() {
        apiKey = keyField.text.trim()
        if (!apiKey) { status.text = "VWorld 인증키를 먼저 입력하세요."; dialog.open(); return }
        coordsX = xField.text.trim()
        coordsY = yField.text.trim()
        if (!coordsX || !coordsY || !isFinite(Number(coordsX)) || !isFinite(Number(coordsY))) {
            status.text = "지도에서 지점을 길게 누르거나 좌표를 입력하세요."
            dialog.open(); return
        }
        if (keepKey) preferences.savedKey = apiKey
        parcelAddress = "조회 중..."
        roadAddress = "조회 중..."
        busy = true
        outstanding = 2
        lookupSerial += 1
        var serial = lookupSerial
        status.text = "지번주소·도로명주소 조회 중..."
        queryAddress("PARCEL", serial)
        queryAddress("ROAD", serial)
    }

    Component.onCompleted: {
        keepKey = preferences.rememberKey
        if (keepKey) apiKey = preferences.savedKey
        keyField.text = apiKey
        iface.addItemToPluginsToolbar(actionButton)
    }

    ToolButton {
        id: actionButton
        text: "주소"
        onClicked: { dialog.open() }
    }

    Dialog {
        id: dialog
        title: "VWorld 주소 조회 (v0.3 시험판)"
        modal: true
        parent: iface.mainWindow().contentItem
        visible: false
        anchors.centerIn: parent
        width: Math.min(parent ? parent.width - 24 : 360, 440)
        standardButtons: Dialog.Close

        contentItem: ColumnLayout {
            spacing: 7
            Label { text: "지도 길게 누르기 → 주소 자동 조회 (키 입력 이후)"; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            TextField {
                id: keyField
                placeholderText: "VWorld 인증키"
                echoMode: TextInput.Password
                Layout.fillWidth: true
                onTextChanged: {
                    plugin.apiKey = text
                    if (plugin.keepKey) preferences.savedKey = text
                }
            }
            CheckBox {
                id: saveCheck
                text: "인증키 기억하기 (암호화되지 않은 앱 설정 저장)"
                checked: plugin.keepKey
                Layout.fillWidth: true
                onToggled: {
                    plugin.keepKey = checked
                    preferences.rememberKey = checked
                    if (checked) preferences.savedKey = keyField.text
                    else preferences.savedKey = ""
                }
            }
            Label { text: plugin.captureInfo; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            Label { text: "EPSG:3857 전용 — 다른 좌표계에서 사용하지 마세요."; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            RowLayout {
                Layout.fillWidth: true
                TextField { id: xField; text: plugin.coordsX; placeholderText: "X"; Layout.fillWidth: true; inputMethodHints: Qt.ImhFormattedNumbersOnly }
                TextField { id: yField; text: plugin.coordsY; placeholderText: "Y"; Layout.fillWidth: true; inputMethodHints: Qt.ImhFormattedNumbersOnly }
            }
            Button { text: plugin.busy ? "조회 중..." : "지번 + 도로명주소 조회"; enabled: !plugin.busy; Layout.fillWidth: true; onClicked: plugin.lookup() }
            Label { text: "지번주소: " + (plugin.parcelAddress || "-"); wrapMode: Text.WrapAnywhere; Layout.fillWidth: true }
            Button { text: "지번주소 복사"; enabled: plugin.parcelAddress !== "" && plugin.parcelAddress !== "조회 중..." && plugin.parcelAddress !== "검색 결과 없음" && plugin.parcelAddress.indexOf("오류") < 0; Layout.fillWidth: true; onClicked: plugin.copyAddress(plugin.parcelAddress) }
            Label { text: "도로명주소: " + (plugin.roadAddress || "-"); wrapMode: Text.WrapAnywhere; Layout.fillWidth: true }
            Button { text: "도로명주소 복사"; enabled: plugin.roadAddress !== "" && plugin.roadAddress !== "조회 중..." && plugin.roadAddress !== "검색 결과 없음" && plugin.roadAddress.indexOf("오류") < 0; Layout.fillWidth: true; onClicked: plugin.copyAddress(plugin.roadAddress) }
            Label { id: status; text: "키를 입력하고 지도를 길게 누른 후 주소 버튼을 누르세요."; wrapMode: Text.WordWrap; Layout.fillWidth: true }
        }
    }
}
