0.3.4: Adjusts only button label location. Kept address search and temporary point code from 0.3.3. Test on QField Android; earlier plugin 0.2.0 stays unchanged.
